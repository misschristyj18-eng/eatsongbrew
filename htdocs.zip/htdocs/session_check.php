<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', '/tmp');

session_start();
?>
<!DOCTYPE html>
<html>
<body>
<h2>Session Check</h2>
<pre><?php print_r($_SESSION); ?></pre>

<p>Session ID: <?php echo session_id(); ?></p>
<p>Save path: <?php echo session_save_path(); ?></p>

<hr>
<p><a href="my_account.php">Pumunta sa my_account.php</a></p>
<p><a href="login.php">Login</a></p>
<p><a href="logout.php">Logout</a></p>
</body>
</html>