/*
  Simple browser-only authentication for the EatSong Brew website.
  This uses localStorage for registered users and sessionStorage for the current session.
  For a real app, you would replace this with a backend and a real password hash.
*/

const USERS_KEY = 'eatsongbrew_users';
const SESSION_KEY = 'eatsongbrew_current_user';
const ORDERS_KEY = 'eatsongbrew_orders';
const ADMIN_EMAIL = 'admin@eatsongbrew.ph';
const ADMIN_PASSWORD = 'admin123';

function hashPassword(password) {
  let hash = 0;

  for (let i = 0; i < password.length; i++) {
    hash = (hash * 31 + password.charCodeAt(i)) >>> 0;
  }

  return 'h' + hash.toString(16);
}

function getUsers() {
  const saved = localStorage.getItem(USERS_KEY);
  return saved ? JSON.parse(saved) : [];
}

function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

function ensureAdminUser() {
  const users = getUsers();
  const adminExists = users.some(user => user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  if (!adminExists) {
    users.push({
      name: 'Admin',
      email: ADMIN_EMAIL,
      password: hashPassword(ADMIN_PASSWORD),
      role: 'admin'
    });

    saveUsers(users);
  }
}

function setCurrentUser(user, rememberMe) {
  const sessionUser = {
    name: user.name,
    email: user.email,
    role: user.role
  };

  sessionStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));

  if (rememberMe) {
    localStorage.setItem(SESSION_KEY, JSON.stringify(sessionUser));
  } else {
    localStorage.removeItem(SESSION_KEY);
  }
}

function getCurrentUser() {
  const sessionData = sessionStorage.getItem(SESSION_KEY);
  if (sessionData) {
    return JSON.parse(sessionData);
  }

  const savedData = localStorage.getItem(SESSION_KEY);
  if (savedData) {
    return JSON.parse(savedData);
  }

  return null;
}

function logoutUser() {
  sessionStorage.removeItem(SESSION_KEY);
  localStorage.removeItem(SESSION_KEY);
  window.location.href = 'login.php';
}

function registerUser(name, email, password, confirmPassword) {
  const trimmedName = name.trim();
  const trimmedEmail = email.trim().toLowerCase();

  if (!trimmedName || !trimmedEmail || !password || !confirmPassword) {
    return { ok: false, message: 'Please complete all fields.' };
  }

  if (password.length < 6) {
    return { ok: false, message: 'Password must be at least 6 characters long.' };
  }

  if (password !== confirmPassword) {
    return { ok: false, message: 'Passwords do not match.' };
  }

  const users = getUsers();
  const duplicate = users.some(user => user.email.toLowerCase() === trimmedEmail);

  if (duplicate) {
    return { ok: false, message: 'This email is already registered.' };
  }

  users.push({
    name: trimmedName,
    email: trimmedEmail,
    password: hashPassword(password),
    role: 'customer'
  });

  saveUsers(users);
  return { ok: true, message: 'Registration successful.' };
}

function loginUser(email, password, rememberMe) {
  const trimmedEmail = email.trim().toLowerCase();

  if (!trimmedEmail || !password) {
    return { ok: false, message: 'Email and password are required.' };
  }

  const users = getUsers();
  const matchedUser = users.find(user => {
    return user.email.toLowerCase() === trimmedEmail && user.password === hashPassword(password);
  });

  if (!matchedUser) {
    return { ok: false, message: 'Invalid email or password.' };
  }

  setCurrentUser(matchedUser, rememberMe);
  return {
    ok: true,
    user: {
      name: matchedUser.name,
      email: matchedUser.email,
      role: matchedUser.role
    }
  };
}

function updateHeaderAuthLink() {
  const link = document.getElementById('authHeaderLink');
  if (!link) return;

  const user = getCurrentUser();
  if (user) {
    if (user.role === 'admin') {
      link.href = 'admin.php';
      link.textContent = 'Admin Dashboard';
    } else {
      link.href = 'index.php';
      link.textContent = 'My Account';
    }
  } else {
    link.href = 'login.php';
    link.textContent = 'Login / My Account';
  }
}

function getOrders() {
  const saved = localStorage.getItem(ORDERS_KEY);
  return saved ? JSON.parse(saved) : [];
}

function saveOrders(orders) {
  localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
}

function renderAdminOrders() {
  const ordersList = document.getElementById('ordersList');
  if (!ordersList) return;

  const orders = getOrders();
  const currentUser = getCurrentUser();

  if (!currentUser || currentUser.role !== 'admin') {
    window.location.href = 'login.html';
    return;
  }

  if (!orders.length) {
    ordersList.innerHTML = '<div class="empty-state">No customer orders yet.</div>';
    return;
  }

  ordersList.innerHTML = orders
    .map((order, index) => {
      const items = order.items && order.items.length
        ? order.items.map(item => `<li>${item.name} x ${item.qty}</li>`).join('')
        : '<li>No items</li>';

      return `
        <article class="order-card">
          <h3>Order #${index + 1}</h3>
          <p><strong>Customer:</strong> ${order.customerName || 'Unknown'}</p>
          <p><strong>Email:</strong> ${order.customerEmail || 'N/A'}</p>
          <p><strong>Date:</strong> ${new Date(order.createdAt).toLocaleString()}</p>
          <p><strong>Total:</strong> ₱${Number(order.total || 0).toLocaleString('en-PH')}</p>
          <ul class="order-items">${items}</ul>
        </article>
      `;
    })
    .join('');
}

function setupAdminPage() {
  const welcomeEl = document.getElementById('welcomeMessage');
  const logoutBtn = document.getElementById('logoutBtn');
  const user = getCurrentUser();

  if (welcomeEl && user) {
    welcomeEl.textContent = `Welcome, ${user.name}`;
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', logoutUser);
  }

  renderAdminOrders();
}

function setupAuthForms() {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  if (loginForm) {
    const errorBox = document.getElementById('loginError');

    loginForm.addEventListener('submit', function (event) {
      event.preventDefault();

      const email = document.getElementById('loginEmail').value;
      const password = document.getElementById('loginPassword').value;
      const rememberMe = document.getElementById('rememberMe').checked;
      const result = loginUser(email, password, rememberMe);

      if (!result.ok) {
        errorBox.hidden = false;
        errorBox.textContent = result.message;
        return;
      }

      const destination = result.user.role === 'admin' ? 'admin.php' : 'index.php';
      window.location.href = destination;
    });
  }

  if (registerForm) {
    const errorBox = document.getElementById('registerError');

    registerForm.addEventListener('submit', function (event) {
      event.preventDefault();

      const name = document.getElementById('registerName').value;
      const email = document.getElementById('registerEmail').value;
      const password = document.getElementById('registerPassword').value;
      const confirmPassword = document.getElementById('confirmPassword').value;
      const result = registerUser(name, email, password, confirmPassword);

      if (!result.ok) {
        errorBox.hidden = false;
        errorBox.textContent = result.message;
        return;
      }

      errorBox.hidden = true;
      alert('Registration successful! You can now log in.');
      window.location.href = 'login.php';
    });
  }
}

document.addEventListener('DOMContentLoaded', function () {
  ensureAdminUser();
  updateHeaderAuthLink();

  if (typeof window.renderUserOrders === 'function') {
    window.renderUserOrders();
  }

  setupAuthForms();
  setupAdminPage();
});

window.eatsongAuth = {
  ensureAdminUser,
  getCurrentUser,
  loginUser,
  registerUser,
  logoutUser,
  getOrders,
  saveOrders,
  hashPassword
};
