/* ===== EDIT HERE ===== */
/* Your story: one string per paragraph. Replace with your own words. */
const STORY = [
  'EatSong Brew is a pop-up coffee shop built around one simple idea: good iced coffee and easy food, in a place where you can take your time.',
  'Our menu keeps it simple. Iced lattes, salted caramel, mocha and matcha, plus fries, burgers, sandwiches and nachos to go with them.',
  'Because we’re a pop-up, our spot can change. Check where we are and when we’re open below before you come.'
];

/* The team shown to customers. */
const TEAM = [
  { name: 'Minerva Mira',        role: 'CEO and website administrator', note: 'Runs EatSong Brew and manages this website.' },
  { name: 'Wendeline Azumbrado', role: 'Manager',                       note: 'Keeps the pop-up running day to day.' },
  { name: 'Melissa Sain',        role: 'Staff',                         note: 'Serves your drinks and food.' }
];

/* Location and links. Leave a value '' if you don't have it yet. */
const VISIT = {
  where:     'Salvador Calo Street, P4, Barangay Doongan, Butuan City',
  mapLink:   'https://www.google.com/maps/search/?api=1&query=Salvador+Calo+Street+Doongan+Butuan+City',
  contact:   '',   // e.g. '0900 000 0000'
  facebook:  'https://www.facebook.com/mb.119085',
  instagram: ''    // e.g. 'https://instagram.com/yourpage'
};

/* Opening hours. Write times like '8:00 AM - 9:00 PM', or 'Closed'.
   Leave '' to show "To be announced". */
const TIMEZONE = 'Asia/Manila';
const HOURS = {
  Monday: '8:00 AM - 9:00 PM', Tuesday: '8:00 AM - 9:00 PM', Wednesday: '8:00 AM - 9:00 PM',
  Thursday: '8:00 AM - 9:00 PM', Friday: '8:00 AM - 9:00 PM', Saturday: '8:00 AM - 9:00 PM',
  Sunday: 'Closed'
};

const ITEMS = [
  { id:1,  cat:'coffee', name:'Latte',                 prices:[49,59] },
  { id:2,  cat:'coffee', name:'Vanilla',               prices:[49,59] },
  { id:3,  cat:'coffee', name:'Salted Caramel',        prices:[59,69] },
  { id:4,  cat:'coffee', name:'Mocha',                 prices:[59,69] },
  { id:5,  cat:'coffee', name:'Matcha Latte',          prices:[69,79] },
  { id:6,  cat:'food',   name:'Fries',                 prices:[39], opts:['Cheese','BBQ','Sour cream'] },
  { id:7,  cat:'food',   name:'B1T1 Burger',           prices:[59] },
  { id:8,  cat:'food',   name:'Ham & Cheese Sandwich', prices:[69] },
  { id:9,  cat:'food',   name:'Nachos',                prices:[69] },
  { id:10, cat:'food',   name:'Cheezy Egg Sandwich',   prices:[79] }
];
/* ===================== */

const $  = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;','\'':'&#39;'}[c]));
const peso = n => '\u20B1' + Number(n || 0).toLocaleString('en-PH');
const state = { cat:'coffee', size:'med', flavor:{}, tray:[] };

function getStoredOrders(){
  try {
    return JSON.parse(localStorage.getItem('eatsongbrew_orders') || '[]');
  } catch (error) {
    return [];
  }
}

async function loadUserOrdersFromServer(){
  const list = $('#userOrdersList');
  if (!list) return;

  try {
    const response = await fetch('save_order.php?action=history', { method: 'GET' });
    const result = await response.json();

    if (!result.ok || !Array.isArray(result.orders)) {
      list.innerHTML = '<div class="empty-orders">Unable to load your orders right now.</div>';
      return;
    }

    if (!result.orders.length) {
      list.innerHTML = '<div class="empty-orders">You have no saved orders yet.</div>';
      return;
    }

    list.innerHTML = result.orders.map((order, idx) => {
      const items = (order.items || []).map(item => `<li>${item.name} x ${item.qty}</li>`).join('');
      return `
        <article class="order-summary">
          <h3>Order #${idx + 1}</h3>
          <p><strong>Date:</strong> ${new Date(order.created_at).toLocaleString()}</p>
          <p><strong>Total:</strong> ₱${Number(order.total || 0).toLocaleString('en-PH')}</p>
          <ul>${items}</ul>
        </article>
      `;
    }).join('');
  } catch (error) {
    list.innerHTML = '<div class="empty-orders">Log in to see your saved orders.</div>';
  }
}

function renderUserOrders(){
  const list = $('#userOrdersList');
  if (!list) return;

  const user = window.eatsongAuth ? window.eatsongAuth.getCurrentUser() : null;
  if (!user) {
    list.innerHTML = '<div class="empty-orders">Log in to see your saved orders.</div>';
    return;
  }

  loadUserOrdersFromServer();
}

async function placeCurrentOrder(){
  const user = window.eatsongAuth ? window.eatsongAuth.getCurrentUser() : null;
  if (!user) {
    window.location.href = 'login.php';
    return;
  }

  if (!state.tray.length) {
    toast('Your order is empty.');
    return;
  }

  const items = state.tray.map(entry => {
    const it = ITEMS.find(item => item.id === entry.id);
    return {
      name: it ? it.name : 'Item',
      qty: entry.qty,
      size: entry.size,
      option: entry.opt || ''
    };
  });

  const total = state.tray.reduce((sum, entry) => {
    const it = ITEMS.find(item => item.id === entry.id);
    return sum + (it ? priceOf(it, entry.size) * entry.qty : 0);
  }, 0);

  try {
    const response = await fetch('save_order.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items, total })
    });

    const result = await response.json();

    if (!response.ok || !result.ok) {
      toast(result.message || 'Order could not be saved.');
      return;
    }

    state.tray = [];
    renderTray();
    renderUserOrders();
    toast('Order placed successfully');
  } catch (error) {
    toast('Order could not be saved.');
  }
}

function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 1700);
}
const priceOf = (it, size) => it.cat === 'coffee' ? it.prices[size === 'med' ? 0 : 1] : it.prices[0];

function renderMenu(){
  $$('#catTabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.cat === state.cat));
  $$('#sizeTabs button').forEach(b => b.setAttribute('aria-pressed', b.dataset.size === state.size));
  $('#sizeTabs').hidden = state.cat !== 'coffee';
  $('#menuTitle').textContent = state.cat === 'coffee' ? 'Iced coffee' : 'Food';
  $('#menuList').innerHTML = ITEMS.filter(i => i.cat === state.cat).map(i => {
    const fl = i.opts ? (state.flavor[i.id] = state.flavor[i.id] || i.opts[0]) : '';
    const flavors = i.opts ? `<div class="flavors" role="group" aria-label="Flavor for ${esc(i.name)}">${i.opts.map(o =>
      `<button type="button" data-flavor="${i.id}" data-value="${esc(o)}" aria-pressed="${o === fl}">${esc(o)}</button>`).join('')}</div>` : '';
    return `<li class="row">
      <div class="r-main"><span class="r-name">${esc(i.name)}</span>${flavors}</div>
      <span class="r-price">${peso(priceOf(i, state.size))}</span>
      <button class="btn small" type="button" data-add="${i.id}" aria-label="Add ${esc(i.name)}">Add</button></li>`;
  }).join('');
}

function renderTray(){
  const ls = state.tray.map(l => ({ ...l, it: ITEMS.find(i => i.id === l.id) }));
  const total = ls.reduce((s, l) => s + priceOf(l.it, l.size) * l.qty, 0);
  const count = ls.reduce((s, l) => s + l.qty, 0);
  $('#trayList').innerHTML = ls.length ? ls.map((l, idx) => `
    <li><div><strong>${esc(l.it.name)}</strong>
      <span class="muted">${esc([l.it.cat === 'coffee' ? (l.size === 'med' ? 'Medium' : 'Large') : '', l.opt].filter(Boolean).join(', '))}</span></div>
      <div class="qty"><button type="button" data-dec="${idx}" aria-label="Remove one ${esc(l.it.name)}">−</button><span>${l.qty}</span><button type="button" data-inc="${idx}" aria-label="Add one ${esc(l.it.name)}">+</button></div>
      <span class="line-price">${peso(priceOf(l.it, l.size) * l.qty)}</span></li>`).join('')
    : '<li class="empty">Nothing yet. Tap Add on any item.</li>';
  $('#trayTotal').textContent = peso(total);
  $('#trayCount').textContent = count;
  $('#clearTray').hidden = !ls.length;
  updatePill(count, total);
}

function addToTray(id){
  const it = ITEMS.find(i => i.id === id);
  const size = it.cat === 'coffee' ? state.size : null;
  const opt = it.opts ? state.flavor[id] : '';
  const found = state.tray.find(l => l.id === id && l.size === size && l.opt === opt);
  found ? found.qty++ : state.tray.push({ id, size, opt, qty: 1 });
  renderTray(); toast(`${it.name} added`);
}

document.addEventListener('click', e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.cat)    { state.cat = t.dataset.cat; return renderMenu(); }
  if (t.dataset.size)   { state.size = t.dataset.size; renderMenu(); return; }
  if (t.dataset.flavor) { state.flavor[t.dataset.flavor] = t.dataset.value; return renderMenu(); }
  if (t.dataset.add)    return addToTray(Number(t.dataset.add));
  if (t.dataset.inc)    { state.tray[Number(t.dataset.inc)].qty++; return renderTray(); }
  if (t.dataset.dec)    { const i = Number(t.dataset.dec); if (--state.tray[i].qty <= 0) state.tray.splice(i, 1); return renderTray(); }
  if (t.id === 'clearTray') { state.tray = []; renderTray(); return; }
  if (t.id === 'placeOrderBtn') { placeCurrentOrder(); }
});

/* story, team, visit */
(function(){
  $('#storyText').innerHTML = STORY.map(p => `<p>${esc(p)}</p>`).join('');

  $('#teamList').innerHTML = TEAM.map(m => `
    <li class="person"><span class="n">${esc(m.name)}</span><span class="r">${esc(m.role)}</span>
    ${m.note ? `<span class="d">${esc(m.note)}</span>` : ''}</li>`).join('');

  const where = $('#where');
  if (VISIT.where) where.textContent = VISIT.where;
  else { where.innerHTML = '<span class="tbd">Location to be announced</span>'; }

  const link = (label, url) => `<a href="${esc(url)}" target="_blank" rel="noopener">${label}</a>`;
  const links = [];
  if (VISIT.mapLink)   links.push(link('Open in maps', VISIT.mapLink));
  if (VISIT.contact)   links.push(`<span>Contact: ${esc(VISIT.contact)}</span>`);
  if (VISIT.facebook)  links.push(link('Facebook: Minerva Mira', VISIT.facebook));
  if (VISIT.instagram) links.push(link('Instagram', VISIT.instagram));
  $('#links').innerHTML = links.join('');

  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const shopNow = new Date(new Date().toLocaleString('en-US', { timeZone: TIMEZONE }));
  const today = days[shopNow.getDay()];
  $('#hours').innerHTML = Object.entries(HOURS).map(([d, t]) =>
    `<tr class="${d === today ? 'today' : ''}"><th scope="row">${esc(d)}</th><td>${t ? esc(t) : '<span class="tbd">To be announced</span>'}</td></tr>`).join('');

  /* "Open now" line, based on the shop's time zone */
  const toMin = (h, m, ap) => (Number(h) % 12 + (/pm/i.test(ap) ? 12 : 0)) * 60 + (Number(m) || 0);
  const t = HOURS[today] || '';
  const m = t.match(/(\d{1,2}):?(\d{2})?\s*(AM|PM)\s*[-\u2013to]+\s*(\d{1,2}):?(\d{2})?\s*(AM|PM)/i);
  const st = $('#status');
  if (m) {
    const now = shopNow.getHours() * 60 + shopNow.getMinutes();
    const isOpen = now >= toMin(m[1], m[2], m[3]) && now < toMin(m[4], m[5], m[6]);
    st.textContent = isOpen ? `Open now until ${m[4]}:${m[5] || '00'} ${m[6].toUpperCase()}` : 'Closed right now';
    st.classList.toggle('open', isOpen); st.hidden = false;
  } else if (/closed/i.test(t)) {
    st.textContent = 'Closed today'; st.hidden = false;
  }
})();

/* hero cup */
const iceG = $('#ice'); let cubes = 0;
$('#cup').addEventListener('click', () => {
  if (cubes >= 6) { iceG.innerHTML = ''; cubes = 0; return; }
  const x = 75 + Math.random() * 90, y = 190 + Math.random() * 55, r = Math.random() * 70 - 35;
  const ns = 'http://www.w3.org/2000/svg';
  const g = document.createElementNS(ns, 'g'); g.setAttribute('transform', `translate(${x} ${y}) rotate(${r})`);
  const c = document.createElementNS(ns, 'rect');
  c.setAttribute('class', 'cube'); c.setAttribute('x', -17); c.setAttribute('y', -17);
  c.setAttribute('width', 34); c.setAttribute('height', 34); c.setAttribute('rx', 7); c.setAttribute('fill', '#fff');
  g.appendChild(c); iceG.appendChild(g); cubes++;
});
requestAnimationFrame(() => setTimeout(() => $('#heroStage').classList.add('filled'), 250));

/* mobile order pill: shows the total and jumps to the order box */
let trayVisible = false, lastCount = 0, lastTotal = 0;
function updatePill(count, total){
  lastCount = count; lastTotal = total;
  $('#cartPill').hidden = !count || trayVisible;
  $('#pillText').textContent = `View order (${count})`;
  $('#pillTotal').textContent = peso(total);
}
new IntersectionObserver(es => { trayVisible = es[0].isIntersecting; updatePill(lastCount, lastTotal); }, { threshold: .15 }).observe($('aside.tray'));
$('#cartPill').addEventListener('click', () => $('aside.tray').scrollIntoView({ behavior: 'smooth', block: 'center' }));

$('#yr').textContent = new Date().getFullYear();
window.renderUserOrders = renderUserOrders;
renderMenu(); renderTray(); renderUserOrders();
