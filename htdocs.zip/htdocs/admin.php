<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
require __DIR__ . '/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->query('SELECT o.*, u.name AS customer_name, u.email AS customer_email FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.created_at DESC');
$orders = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard | EatSong Brew</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Lora:ital,wght@0,500;0,600;0,700;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/auth.css">
</head>
<body>
  <style>
    .admin-wrap { max-width: 900px; margin: 2rem auto; padding: 0 1.25rem; }
    .admin-head { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(62,51,43,.18); padding-bottom: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
    .admin-head h1 { font-family: 'Lora', Georgia, serif; margin: 0; font-size: 1.9rem; }
    .admin-head p { margin: .25rem 0 0; color: #6B5D4F; }
    .order-card { background: #FFFCF6; border: 1px solid rgba(62,51,43,.18); border-radius: 14px; padding: 1rem 1.15rem; margin-bottom: 1rem; }
    .order-card h3 { font-family: 'Lora', Georgia, serif; margin: 0 0 .4rem; font-size: 1.15rem; }
    .order-card p { margin: .2rem 0; color: #6B5D4F; font-size: .92rem; }
    .order-card ul { margin: .5rem 0 0; padding-left: 1.2rem; color: #3E332B; }
    .order-card ul li { font-size: .95rem; }
    .empty-box { padding: 1.25rem; border: 1px dashed rgba(62,51,43,.18); background: #FFFCF6; color: #6B5D4F; border-radius: 12px; text-align: center; }
    .toolbar { display: flex; justify-content: flex-end; margin-bottom: 1rem; }
    .toolbar button { border: none; background: #B9683A; color: #fff; padding: .7rem 1.2rem; border-radius: 999px; cursor: pointer; font-weight: 700; }
    .nav-top { padding: 1rem 1.5rem; border-bottom: 1px solid rgba(62,51,43,.18); background: rgba(248,241,228,.94); }
    .nav-top .inner { max-width: 900px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
    .nav-top a { color: #3E332B; text-decoration: none; font-weight: 500; }
    .nav-top .brand { font-family: 'Lora', serif; font-weight: 600; letter-spacing: .16em; color: #6B5D4F; }
  </style>

  <header class="nav-top">
    <div class="inner">
      <a href="index.php" class="brand">EATSONG BREW</a>
      <nav style="display:flex;gap:1.2rem;">
        <a href="index.php">Home</a>
        <a href="logout.php">Logout</a>
      </nav>
    </div>
  </header>

  <div class="admin-wrap">
    <div class="admin-head">
      <div>
        <p style="color:#1F5B4A;font-weight:700;text-transform:uppercase;letter-spacing:.12em;font-size:.78rem;margin:0 0 .4rem;">Admin Dashboard</p>
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></h1>
      </div>
    </div>

    <div class="toolbar">
      <button type="button" id="exportBtn">Export to CSV</button>
    </div>

    <h2 style="font-family:'Lora',serif;font-size:1.4rem;margin:0 0 1rem;">All Orders</h2>

    <div id="ordersList">
      <?php if (empty($orders)): ?>
        <div class="empty-box">No customer orders yet.</div>
      <?php else: ?>
        <?php foreach ($orders as $index => $order): ?>
          <?php $items = json_decode($order['items'], true) ?: []; ?>
          <article class="order-card">
            <h3>Order #<?php echo $index + 1; ?></h3>
            <p><strong>Customer:</strong> <?php echo htmlspecialchars($order['customer_name'] ?: 'Unknown'); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email'] ?: 'N/A'); ?></p>
            <p><strong>Date:</strong> <?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></p>
            <p><strong>Total:</strong> ₱<?php echo number_format((float) $order['total'], 2); ?></p>
            <ul>
              <?php foreach ($items as $item): ?>
                <li><?php echo htmlspecialchars($item['name']); ?> x <?php echo (int) $item['qty']; ?></li>
              <?php endforeach; ?>
            </ul>
          </article>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <script>
    document.getElementById('exportBtn')?.addEventListener('click', () => {
      const rows = [['Order #','Customer','Email','Date','Total','Items']];
      document.querySelectorAll('.order-card').forEach((card, i) => {
        const get = sel => (card.querySelector(sel)?.textContent || '').replace(/^[^:]+:\s*/, '').trim();
        const items = [...card.querySelectorAll('ul li')].map(li => li.textContent.trim()).join(' | ');
        rows.push([i + 1, get('p:nth-of-type(1)'), get('p:nth-of-type(2)'), get('p:nth-of-type(3)'), get('p:nth-of-type(4)'), items]);
      });
      const csv = rows.map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(',')).join('\n');
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'eatsongbrew-orders.csv';
      a.click();
    });
  </script>
</body>
</html>