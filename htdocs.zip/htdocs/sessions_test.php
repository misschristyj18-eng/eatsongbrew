<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');
session_start();

echo "<h2>Session Test</h2>";
echo "<p><b>Save path set to:</b> " . session_save_path() . "</p>";
echo "<p><b>Folder exists?</b> " . (is_dir(session_save_path()) ? '✅ YES' : '❌ NO') . "</p>";
echo "<p><b>Folder writable?</b> " . (is_writable(session_save_path()) ? '✅ YES' : '❌ NO') . "</p>";
echo "<p><b>Session ID:</b> " . session_id() . "</p>";

if (!isset($_SESSION['counter'])) {
    $_SESSION['counter'] = 1;
    echo "<p>🆕 Bagong session — counter = 1</p>";
} else {
    $_SESSION['counter']++;
    echo "<p>✅ Session gumagana! Counter = " . $_SESSION['counter'] . "</p>";
}

echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo '<p><a href="sessions_test.php">Refresh</a></p>';