<?php
require __DIR__ . '/db.php';

$sql = "
CREATE DATABASE IF NOT EXISTS eatsongbrew;
USE eatsongbrew;

CREATE TABLE IF NOT EXISTS users (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer','admin') DEFAULT 'customer',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS orders (
    id INT NOT NULL AUTO_INCREMENT,
    user_id INT NOT NULL,
    customer_name VARCHAR(150) NOT NULL,
    customer_email VARCHAR(150) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    items TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY user_id (user_id),
    CONSTRAINT orders_ibfk_1 FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO users (name, email, password, role, created_at)
SELECT 'Admin', 'admin@eatsongbrew.ph', '$2y$10$Q7dF7h8v0Cj3yq3hJjK7QeG6p7A7wQ5x7pM9W9Y8j3Vx6WHzF7Q2', 'admin', '2026-09-21 06:15:02'
WHERE NOT EXISTS (
    SELECT 1 FROM users WHERE email = 'admin@eatsongbrew.ph'
);
";

try {
    $pdo->exec($sql);
    echo 'Database setup complete.';
} catch (PDOException $e) {
    echo 'Setup failed: ' . $e->getMessage();
}
