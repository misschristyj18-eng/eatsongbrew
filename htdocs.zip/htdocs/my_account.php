<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
require __DIR__ . '/db.php';

if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
if ($_SESSION['user_role'] === 'admin') { header('Location: admin.php'); exit; }

$userId    = (int) $_SESSION['user_id'];
$userName  = $_SESSION['user_name'];
$userEmail = $_SESSION['user_email'];

$stmt = $pdo->prepare('SELECT * FROM orders WHERE user_id = :uid ORDER BY created_at DESC');
$stmt->execute(['uid' => $userId]);
$orders = $stmt->fetchAll();

$totalSpent = 0;
foreach ($orders as $o) { $totalSpent += (float) $o['total']; }
$orderCount = count($orders);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Account | EatSong Brew</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Lora:ital,wght@0,500;0,600;0,700;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/auth.css">
  <style>
    .cust-wrap { max-width: 760px; margin: 2rem auto; padding: 0 1.25rem; }
    .cust-head { border-bottom: 1px solid rgba(62,51,43,.18); padding-bottom: 1rem; margin-bottom: 1.5rem; }
    .cust-head h1 { font-family: 'Lora', Georgia, serif; margin: 0; font-size: 2rem; }
    .cust-head p { margin: .25rem 0 0; color: #6B5D4F; }
    .cust-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
    .cust-stat { background: #FFFCF6; border: 1px solid rgba(62,51,43,.18); border-radius: 14px; padding: 1.2rem; }
    .cust-stat .lbl { color: #6B5D4F; font-size: .85rem; text-transform: uppercase; letter-spacing: .05em; margin: 0 0 .3rem; }
    .cust-stat .val { font-family: 'Lora', Georgia, serif; font-size: 1.8rem; font-weight: 700; margin: 0; color: #1F5B4A; }
    .ord { background: #FFFCF6; border: 1px solid rgba(62,51,43,.18); border-radius: 14px; padding: 1rem 1.15rem; margin-bottom: 1rem; }
    .ord h3 { font-family: 'Lora', Georgia, serif; margin: 0 0 .4rem; font-size: 1.15rem; }
    .ord p { margin: .2rem 0; color: #6B5D4F; font-size: .92rem; }
    .ord ul { margin: .5rem 0 0; padding-left: 1.2rem; color: #3E332B; }
    .ord ul li { font-size: .95rem; }
    .empty-box { padding: 1.25rem; border: 1px dashed rgba(62,51,43,.18); background: #FFFCF6; color: #6B5D4F; border-radius: 12px; text-align: center; }
    .btn-row { margin-top: 1.5rem; display: flex; gap: .6rem; flex-wrap: wrap; }
    .btn-row a { display: inline-block; padding: .7rem 1.4rem; border-radius: 999px; font-weight: 600; text-decoration: none; }
    .btn-primary { background: #1F5B4A; color: #fff; }
    .btn-ghost { background: transparent; color: #6B5D4F; box-shadow: inset 0 0 0 1.5px rgba(62,51,43,.18); }
  </style>
</head>
<body>
  <header style="padding: 1rem 1.5rem; border-bottom: 1px solid rgba(62,51,43,.18); background: rgba(248,241,228,.94);">
    <div style="max-width: 760px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center;">
      <a href="index.php" style="font-family: 'Lora', serif; font-weight: 600; letter-spacing: .16em; color: #6B5D4F; text-decoration: none;">EATSONG BREW</a>
      <nav style="display: flex; gap: 1.2rem;">
        <a href="index.php" style="color: #3E332B; text-decoration: none; font-weight: 500;">Home</a>
        <a href="index.php#menu" style="color: #3E332B; text-decoration: none; font-weight: 500;">Menu</a>
        <a href="logout.php" style="color: #3E332B; text-decoration: none; font-weight: 500;">Logout</a>
      </nav>
    </div>
  </header>

  <div class="cust-wrap">
    <div class="cust-head">
      <p style="color: #1F5B4A; font-weight: 700; text-transform: uppercase; letter-spacing: .12em; font-size: .78rem; margin: 0 0 .4rem;">My Account</p>
      <h1>Welcome, <?php echo htmlspecialchars($userName); ?></h1>
      <p><?php echo htmlspecialchars($userEmail); ?> · Customer</p>
    </div>

    <div class="cust-stats">
      <div class="cust-stat">
        <p class="lbl">Total Orders</p>
        <p class="val"><?php echo $orderCount; ?></p>
      </div>
      <div class="cust-stat">
        <p class="lbl">Total Spent</p>
        <p class="val">₱<?php echo number_format($totalSpent, 2); ?></p>
      </div>
    </div>

    <h2 style="font-family: 'Lora', serif; font-size: 1.4rem; margin: 0 0 1rem;">My Orders</h2>

    <?php if (empty($orders)): ?>
      <div class="empty-box">
        <p>Wala ka pang order.</p>
        <a href="index.php#menu" style="display: inline-block; margin-top: .8rem; padding: .6rem 1.2rem; background: #1F5B4A; color: #fff; border-radius: 999px; text-decoration: none; font-weight: 600;">Pumunta sa Menu</a>
      </div>
    <?php else: ?>
      <?php foreach ($orders as $index => $order): ?>
        <?php $items = json_decode($order['items'], true) ?: []; ?>
        <article class="ord">
          <h3>Order #<?php echo $index + 1; ?></h3>
          <p><strong>Date:</strong> <?php echo date('M d, Y h:i A', strtotime($order['created_at'])); ?></p>
          <p><strong>Total:</strong> ₱<?php echo number_format((float) $order['total'], 2); ?></p>
          <ul>
            <?php foreach ($items as $item): ?>
              <li>
                <?php echo htmlspecialchars($item['name']); ?> x <?php echo (int) $item['qty']; ?>
                <?php if (!empty($item['size'])): ?>
                  <span style="color:#6B5D4F;">(<?php echo htmlspecialchars($item['size']); ?>)</span>
                <?php endif; ?>
              </li>
            <?php endforeach; ?>
          </ul>
        </article>
      <?php endforeach; ?>
    <?php endif; ?>

    <div class="btn-row">
      <a href="index.php#menu" class="btn-primary">Order Again</a>
      <a href="logout.php" class="btn-ghost">Logout</a>
    </div>
  </div>
</body>
</html>