<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
$user = null;
if (isset($_SESSION['user_id'])) {
    $user = [
        'id'    => $_SESSION['user_id'],
        'name'  => $_SESSION['user_name'],
        'email' => $_SESSION['user_email'],
        'role'  => $_SESSION['user_role'],
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>EatSong Brew | Eat. Sip. Stay.</title>
  <meta name="description" content="EatSong Brew is a pop-up coffee shop serving iced coffee, matcha and easy bites.">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Lora:ital,wght@0,500;0,600;0,700;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<header class="top">
  <div class="wrap">
    <a class="brand" href="#top" aria-label="EatSong Brew home">
      <svg viewBox="0 0 120 140" aria-hidden="true">
        <path d="M60 80 L70 14 L104 26" stroke="#7FD3CB" stroke-width="9" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
        <path d="M14 56 H106 L98 128 Q97 136 88 136 H32 Q23 136 22 128 Z" fill="#BFE8EA"/>
        <path d="M20 92 Q45 100 62 90 T102 88 L98 126 Q97 132 88 132 H32 Q24 132 23 126 Z" fill="#B9683A"/>
        <rect x="8" y="46" width="104" height="14" rx="6" fill="#F3DFBF"/>
      </svg>
      EATSONG BREW
    </a>
    <nav aria-label="Main">
      <a href="#story">Our story</a>
      <a href="#menu">Menu</a>
      <a href="#team">Team</a>
      <a href="#visit">Visit us</a>
      <?php if ($user && $user['role'] === 'admin'): ?>
        <a href="admin.php" style="font-weight:700;">Admin Dashboard</a>
      <?php elseif ($user): ?>
        <a href="my_account.php" style="font-weight:700;">My Account</a>
      <?php else: ?>
        <a href="login.php" style="font-weight:700;">Login / My Account</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<main id="top">
  <div class="hero" id="heroStage">
    <div class="wrap">
      <div>
        <h1><span>Eat.</span><span>Sip.</span><span>Stay.</span></h1>
        <p class="lede">A pop-up coffee shop serving iced coffee, matcha and easy bites.</p>
        <a class="btn" href="#menu">See the menu</a>
      </div>
      <button class="cup-btn" id="cup" type="button" aria-label="Drop an ice cube into the cup">
        <svg viewBox="0 0 240 310" aria-hidden="true">
          <defs><clipPath id="glassClip"><path d="M40 118 H200 L188 268 Q186 284 170 284 H70 Q54 284 52 268 Z"/></clipPath></defs>
          <path d="M40 118 H200 L188 268 Q186 284 170 284 H70 Q54 284 52 268 Z" fill="#BFE8EA"/>
          <g clip-path="url(#glassClip)">
            <g class="coffee"><path d="M30 172 Q75 158 120 172 T210 172 V420 H30 Z" fill="#B9683A"/></g>
            <g id="ice"></g>
          </g>
          <path d="M126 210 L148 52 L198 68" stroke="#7FD3CB" stroke-width="10" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
          <rect x="28" y="98" width="184" height="22" rx="9" fill="#F3DFBF"/>
        </svg>
        <small>Tap the cup to add ice</small>
      </button>
    </div>
    <svg class="wave" viewBox="0 0 1440 56" preserveAspectRatio="none" aria-hidden="true"><path d="M0 28 Q180 -6 360 28 T720 28 T1080 28 T1440 28 V56 H0 Z" fill="#F8F1E4"/></svg>
  </div>

  <section class="chap" id="story">
    <div class="wrap story">
      <h2>Our story</h2>
      <p class="tagline serif">Eat. Sip. Stay.</p>
      <div id="storyText"></div>
    </div>
  </section>

  <section class="chap alt" id="menu">
    <div class="wrap">
      <h2>Our menu</h2>
      <p class="intro">Pick a size, tap Add, and see your total as you go. Prices are in pesos.</p>
      <div class="menu-grid">
        <div>
          <div class="menu-bar">
            <div class="tabs" id="catTabs" role="tablist" aria-label="Menu category">
              <button role="tab" data-cat="coffee" aria-selected="true">Coffee</button>
              <button role="tab" data-cat="food" aria-selected="false">Food</button>
            </div>
            <div class="tabs" id="sizeTabs" aria-label="Cup size">
              <button data-size="med" aria-pressed="true">Medium</button>
              <button data-size="large" aria-pressed="false">Large</button>
            </div>
          </div>
          <h3 id="menuTitle">Iced coffee</h3>
          <ul class="menu" id="menuList"></ul>
        </div>

        <aside class="tray" aria-label="Your order">
          <h3>Your order <span><b id="trayCount">0</b> items</span></h3>
          <ul id="trayList"></ul>
          <div class="total"><span>Total</span><span id="trayTotal">₱0</span></div>
          <p class="fine">A quick total to help you choose. Nothing is sent or paid here.</p>
          <button class="btn ghost" id="clearTray" type="button" hidden>Clear order</button>
          <button class="btn" id="placeOrderBtn" type="button" style="margin-top: 0.8rem; width: 100%;">Place Order</button>
        </aside>
      </div>
    </div>
  </section>

  <section class="chap" id="team">
    <div class="wrap">
      <h2>Meet the team</h2>
      <p class="intro">The people behind EatSong Brew.</p>
      <ul class="team" id="teamList"></ul>
    </div>
  </section>

  <section class="chap alt" id="visit">
    <div class="wrap">
      <h2>Visit us</h2>
      <p class="intro">EatSong Brew is a pop-up, so check where we are and when we're open before you come.</p>
      <div class="visit-grid">
        <div>
          <h3>Where to find us</h3>
          <p class="where" id="where"></p>
          <p class="links" id="links"></p>
        </div>
        <div>
          <h3>Opening hours</h3>
          <p class="status" id="status" hidden></p>
          <table class="hours" id="hours"></table>
        </div>
      </div>
    </div>
  </section>
</main>

<footer>
  <div class="wrap">
    <span class="serif">EatSong Brew &mdash; Eat. Sip. Stay.</span>
    <span>&copy; <span id="yr"></span> EatSong Brew</span>
  </div>
</footer>

<div id="toast" role="status" aria-live="polite"></div>

<script>
const STORY = [
  'EatSong Brew is a pop-up coffee shop built around one simple idea: good iced coffee and easy food, in a place where you can take your time.',
  'Our menu keeps it simple. Iced lattes, salted caramel, mocha and matcha, plus fries, burgers, sandwiches and nachos to go with them.',
  'Because we\u2019re a pop-up, our spot can change. Check where we are and when we\u2019re open below before you come.'
];

const TEAM = [
  { name: 'Minerva Mira',        role: 'CEO and website administrator', note: 'Runs EatSong Brew and manages this website.' },
  { name: 'Wendeline Azumbrado', role: 'Manager',                       note: 'Keeps the pop-up running day to day.' },
  { name: 'Melissa Sain',        role: 'Staff',                         note: 'Serves your drinks and food.' }
];

const VISIT = {
  where:     'Salvador Calo Street, P4, Barangay Doongan, Butuan City',
  mapLink:   'https://www.google.com/maps/search/?api=1&query=Salvador+Calo+Street+Doongan+Butuan+City',
  contact:   '',
  facebook:  'https://www.facebook.com/mb.119085',
  instagram: ''
};

const TIMEZONE = 'Asia/Manila';
const HOURS = {
  Monday: '8:00 AM - 9:00 PM', Tuesday: '8:00 AM - 9:00 PM', Wednesday: '8:00 AM - 9:00 PM',
  Thursday: '8:00 AM - 9:00 PM', Friday: '8:00 AM - 9:00 PM', Saturday: '8:00 AM - 9:00 PM',
  Sunday: 'Closed'
};

const ITEMS = [
  { id:1,  cat:'coffee', name:'Latte',                 prices:[49,59] },
  { id:2,  cat:'coffee', name:'Vanilla',               prices:[49,59] },
  { id:3,  cat:'coffee', name:'Salted Caramel',        prices:[59,69] },
  { id:4,  cat:'coffee', name:'Mocha',                 prices:[59,69] },
  { id:5,  cat:'coffee', name:'Matcha Latte',          prices:[69,79] },
  { id:6,  cat:'food',   name:'Fries',                 prices:[39], opts:['Cheese','BBQ','Sour cream'] },
  { id:7,  cat:'food',   name:'B1T1 Burger',           prices:[59] },
  { id:8,  cat:'food',   name:'Ham & Cheese Sandwich', prices:[69] },
  { id:9,  cat:'food',   name:'Nachos',                prices:[69] },
  { id:10, cat:'food',   name:'Cheezy Egg Sandwich',   prices:[79] }
];

const $  = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const peso = n => '\u20B1' + Number(n || 0).toLocaleString('en-PH');
const state = { cat:'coffee', size:'med', flavor:{}, tray:[] };

function toast(msg){
  const t = $('#toast'); if (!t) return;
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 1700);
}
const priceOf = (it, size) => it.cat === 'coffee' ? it.prices[size === 'med' ? 0 : 1] : it.prices[0];

function renderMenu(){
  $$('#catTabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.cat === state.cat));
  $$('#sizeTabs button').forEach(b => b.setAttribute('aria-pressed', b.dataset.size === state.size));
  $('#sizeTabs').hidden = state.cat !== 'coffee';
  $('#menuTitle').textContent = state.cat === 'coffee' ? 'Iced coffee' : 'Food';
  $('#menuList').innerHTML = ITEMS.filter(i => i.cat === state.cat).map(i => {
    const fl = i.opts ? (state.flavor[i.id] = state.flavor[i.id] || i.opts[0]) : '';
    const flavors = i.opts ? `<div class="flavors" role="group" aria-label="Flavor for ${esc(i.name)}">${i.opts.map(o =>
      `<button type="button" data-flavor="${i.id}" data-value="${esc(o)}" aria-pressed="${o === fl}">${esc(o)}</button>`).join('')}</div>` : '';
    return `<li class="row">
      <div class="r-main"><span class="r-name">${esc(i.name)}</span>${flavors}</div>
      <span class="r-price">${peso(priceOf(i, state.size))}</span>
      <button class="btn small" type="button" data-add="${i.id}" aria-label="Add ${esc(i.name)}">Add</button></li>`;
  }).join('');
}

function renderTray(){
  const ls = state.tray.map(l => ({ ...l, it: ITEMS.find(i => i.id === l.id) }));
  const total = ls.reduce((s, l) => s + priceOf(l.it, l.size) * l.qty, 0);
  const count = ls.reduce((s, l) => s + l.qty, 0);
  $('#trayList').innerHTML = ls.length ? ls.map((l, idx) => `
    <li><div><strong>${esc(l.it.name)}</strong>
      <span class="muted">${esc([l.it.cat === 'coffee' ? (l.size === 'med' ? 'Medium' : 'Large') : '', l.opt].filter(Boolean).join(', '))}</span></div>
      <div class="qty"><button type="button" data-dec="${idx}" aria-label="Remove one ${esc(l.it.name)}">\u2212</button><span>${l.qty}</span><button type="button" data-inc="${idx}" aria-label="Add one ${esc(l.it.name)}">+</button></div>
      <span class="line-price">${peso(priceOf(l.it, l.size) * l.qty)}</span></li>`).join('')
    : '<li class="empty">Nothing yet. Tap Add on any item.</li>';
  $('#trayTotal').textContent = peso(total);
  $('#trayCount').textContent = count;
  $('#clearTray').hidden = !ls.length;
}

function addToTray(id){
  const it = ITEMS.find(i => i.id === id);
  const size = it.cat === 'coffee' ? state.size : null;
  const opt = it.opts ? state.flavor[id] : '';
  const found = state.tray.find(l => l.id === id && l.size === size && l.opt === opt);
  found ? found.qty++ : state.tray.push({ id, size, opt, qty: 1 });
  renderTray(); toast(`${it.name} added`);
}

async function placeOrder(){
  if (!state.tray.length) return toast('Your order is empty.');
  const user = <?php echo $user ? 'true' : 'false'; ?>;
  if (!user) { window.location.href = 'login.php'; return; }

  const items = state.tray.map(l => {
    const it = ITEMS.find(i => i.id === l.id);
    return { name: it.name, qty: l.qty, size: l.size, option: l.opt || '' };
  });
  const total = state.tray.reduce((s, l) => {
    const it = ITEMS.find(i => i.id === l.id);
    return s + priceOf(it, l.size) * l.qty;
  }, 0);

  try {
    const res = await fetch('save_order.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items, total })
    });
    const result = await res.json();
    if (!result.ok) { toast(result.message || 'Order failed.'); return; }
    state.tray = []; renderTray();
    toast('Order placed!');
    setTimeout(() => window.location.href = 'my_account.php', 800);
  } catch (e) {
    toast('Order could not be saved.');
  }
}

document.addEventListener('click', e => {
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.cat)    { state.cat = t.dataset.cat; return renderMenu(); }
  if (t.dataset.size)   { state.size = t.dataset.size; renderMenu(); return; }
  if (t.dataset.flavor) { state.flavor[t.dataset.flavor] = t.dataset.value; return renderMenu(); }
  if (t.dataset.add)    return addToTray(Number(t.dataset.add));
  if (t.dataset.inc)    { state.tray[Number(t.dataset.inc)].qty++; return renderTray(); }
  if (t.dataset.dec)    { const i = Number(t.dataset.dec); if (--state.tray[i].qty <= 0) state.tray.splice(i, 1); return renderTray(); }
  if (t.id === 'clearTray') { state.tray = []; renderTray(); return; }
  if (t.id === 'placeOrderBtn') { placeOrder(); }
});

(function(){
  $('#storyText').innerHTML = STORY.map(p => `<p>${esc(p)}</p>`).join('');
  $('#teamList').innerHTML = TEAM.map(m => `<li class="person"><span class="n">${esc(m.name)}</span><span class="r">${esc(m.role)}</span>${m.note ? `<span class="d">${esc(m.note)}</span>` : ''}</li>`).join('');

  const where = $('#where');
  if (VISIT.where) where.textContent = VISIT.where; else where.innerHTML = '<span class="tbd">Location to be announced</span>';

  const link = (label, url) => `<a href="${esc(url)}" target="_blank" rel="noopener">${label}</a>`;
  const links = [];
  if (VISIT.mapLink)   links.push(link('Open in maps', VISIT.mapLink));
  if (VISIT.contact)   links.push(`<span>Contact: ${esc(VISIT.contact)}</span>`);
  if (VISIT.facebook)  links.push(link('Facebook: Minerva Mira', VISIT.facebook));
  if (VISIT.instagram) links.push(link('Instagram', VISIT.instagram));
  $('#links').innerHTML = links.join('');

  const days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const shopNow = new Date(new Date().toLocaleString('en-US', { timeZone: TIMEZONE }));
  const today = days[shopNow.getDay()];
  $('#hours').innerHTML = Object.entries(HOURS).map(([d, t]) =>
    `<tr class="${d === today ? 'today' : ''}"><th scope="row">${esc(d)}</th><td>${t ? esc(t) : '<span class="tbd">To be announced</span>'}</td></tr>`).join('');

  const toMin = (h, m, ap) => (Number(h) % 12 + (/pm/i.test(ap) ? 12 : 0)) * 60 + (Number(m) || 0);
  const t = HOURS[today] || '';
  const m = t.match(/(\d{1,2}):?(\d{2})?\s*(AM|PM)\s*[-\u2013to]+\s*(\d{1,2}):?(\d{2})?\s*(AM|PM)/i);
  const st = $('#status');
  if (m) {
    const now = shopNow.getHours() * 60 + shopNow.getMinutes();
    const isOpen = now >= toMin(m[1], m[2], m[3]) && now < toMin(m[4], m[5], m[6]);
    st.textContent = isOpen ? `Open now until ${m[4]}:${m[5] || '00'} ${m[6].toUpperCase()}` : 'Closed right now';
    st.classList.toggle('open', isOpen); st.hidden = false;
  } else if (/closed/i.test(t)) { st.textContent = 'Closed today'; st.hidden = false; }
})();

const iceG = $('#ice'); let cubes = 0;
$('#cup').addEventListener('click', () => {
  if (cubes >= 6) { iceG.innerHTML = ''; cubes = 0; return; }
  const x = 75 + Math.random() * 90, y = 190 + Math.random() * 55, r = Math.random() * 70 - 35;
  const ns = 'http://www.w3.org/2000/svg';
  const g = document.createElementNS(ns, 'g'); g.setAttribute('transform', `translate(${x} ${y}) rotate(${r})`);
  const c = document.createElementNS(ns, 'rect');
  c.setAttribute('class', 'cube'); c.setAttribute('x', -17); c.setAttribute('y', -17);
  c.setAttribute('width', 34); c.setAttribute('height', 34); c.setAttribute('rx', 7); c.setAttribute('fill', '#fff');
  g.appendChild(c); iceG.appendChild(g); cubes++;
});
requestAnimationFrame(() => setTimeout(() => $('#heroStage').classList.add('filled'), 250));

$('#yr').textContent = new Date().getFullYear();
renderMenu(); renderTray();
</script>
</body>
</html>