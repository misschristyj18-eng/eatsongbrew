<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
require __DIR__ . '/db.php';

if (isset($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['user_role'] === 'admin' ? 'admin.php' : 'my_account.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($name === '' || $email === '' || $password === '' || $confirmPassword === '') {
        $error = 'Please complete all fields.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } else {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = :email LIMIT 1');
        $check->execute(['email' => $email]);

        if ($check->fetch()) {
            $error = 'This email is already registered.';
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (:name, :email, :password, :role)');
            $stmt->execute([
                'name' => $name,
                'email' => $email,
                'password' => $hashed,
                'role' => 'customer'
            ]);
            header('Location: login.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register | EatSong Brew</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Lora:ital,wght@0,500;0,600;0,700;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/auth.css">
</head>
<body class="auth-page">
  <div class="auth-shell">
    <div class="auth-card">
      <div class="brand-block">
        <h1>Create your account</h1>
        <p>Join EatSong Brew to save your favorite drinks and orders.</p>
      </div>

      <form method="POST" action="register.php">
        <div class="field-group">
          <label for="name">Full name</label>
          <input id="name" name="name" type="text" placeholder="Juan Dela Cruz" required>
        </div>

        <div class="field-group">
          <label for="email">Email</label>
          <input id="email" name="email" type="email" placeholder="you@example.com" required>
        </div>

        <div class="field-group">
          <label for="password">Password</label>
          <input id="password" name="password" type="password" placeholder="At least 6 characters" required minlength="6">
        </div>

        <div class="field-group">
          <label for="confirm_password">Confirm password</label>
          <input id="confirm_password" name="confirm_password" type="password" placeholder="Re-enter password" required>
        </div>

        <?php if ($error !== ''): ?>
          <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <button type="submit" class="primary-btn">Register</button>

        <p style="text-align: center; margin-top: 1.2rem; font-size: 1rem; color: #6B5D4F;">
          Already have an account?
          <a href="login.php" style="color: #1F5B4A; font-weight: 700; text-decoration: underline;">Login</a>
        </p>
      </form>
    </div>
  </div>
</body>
</html>