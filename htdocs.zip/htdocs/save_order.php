<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
require __DIR__ . '/db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => 'Please log in to place an order.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'history') {
    $stmt = $pdo->prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20');
    $stmt->execute([(int) $_SESSION['user_id']]);
    $orders = $stmt->fetchAll();
    foreach ($orders as &$o) { $o['items'] = json_decode($o['items'], true) ?: []; }
    unset($o);
    echo json_encode(['ok' => true, 'orders' => $orders]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid order data.']);
    exit;
}

$items = $data['items'] ?? [];
$total = (float) ($data['total'] ?? 0);

if (empty($items)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Your order is empty.']);
    exit;
}

$stmt = $pdo->prepare('INSERT INTO orders (user_id, customer_name, customer_email, total, items) VALUES (?, ?, ?, ?, ?)');
$stmt->execute([
    (int) $_SESSION['user_id'],
    $_SESSION['user_name'],
    $_SESSION['user_email'],
    $total,
    json_encode($items)
]);

echo json_encode(['ok' => true, 'message' => 'Order saved successfully.']);