<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('session.save_path', '/tmp');
session_start();

if (!isset($_SESSION['counter'])) {
    $_SESSION['counter'] = 1;
    $_SESSION['started'] = date('H:i:s');
    echo "<h2>🆕 Bagong session — nag-set ng counter = 1</h2>";
} else {
    $_SESSION['counter']++;
    echo "<h2>✅ Session gumagana! Counter = " . $_SESSION['counter'] . "</h2>";
    echo "<p>Started at: " . $_SESSION['started'] . "</p>";
}

echo "<p>Session ID: <strong>" . session_id() . "</strong></p>";
echo "<p>Save path: <strong>" . session_save_path() . "</strong></p>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

echo '<p><a href="session_write_test.php">Refresh page</a></p>';