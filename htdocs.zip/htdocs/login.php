<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);
ini_set('display_errors', 1);
ini_set('session.save_path', __DIR__ . '/sessions');

session_start();
require __DIR__ . '/db.php';

if (isset($_SESSION['user_id'])) {
    session_write_close();
    header('Location: ' . ($_SESSION['user_role'] === 'admin' ? 'admin.php' : 'my_account.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email LIMIT 1');
        $stmt->execute(['email' => strtolower($email)]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']    = (int) $user['id'];
            $_SESSION['user_name']  = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role']  = $user['role'];

            session_write_close();   // ⬅️ ITO ANG FIX

            if ($user['role'] === 'admin') {
                header('Location: admin.php');
            } else {
                header('Location: my_account.php');
            }
            exit;
        }
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | EatSong Brew</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&family=Lora:ital,wght@0,500;0,600;0,700;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/auth.css">
</head>
<body class="auth-page">
  <div class="auth-shell">
    <div class="auth-card">
      <div class="brand-block">
        <h1>EatSong Brew</h1>
        <p>Log in to save your orders and keep track of your favorites.</p>
      </div>

      <form method="POST" action="login.php">
        <div class="field-group">
          <label for="email">Email</label>
          <input id="email" name="email" type="email" placeholder="you@example.com" required>
        </div>

        <div class="field-group">
          <label for="password">Password</label>
          <input id="password" name="password" type="password" placeholder="••••••••" required>
        </div>

        <div class="row-between">
          <label class="checkbox-wrap">
            <input type="checkbox" name="remember_me">
            <span>Remember me</span>
          </label>
          <a href="index.php" class="text-link">Back to home</a>
        </div>

        <?php if ($error !== ''): ?>
          <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <button type="submit" class="primary-btn">Login</button>

        <p style="text-align: center; margin-top: 1.2rem; font-size: 1rem; color: #6B5D4F;">
          Don't have an account?
          <a href="register.php" style="color: #1F5B4A; font-weight: 700; text-decoration: underline;">Create one</a>
        </p>
      </form>
    </div>
  </div>
</body>
</html>